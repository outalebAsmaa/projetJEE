package org.sid.announcementService.entities;

public enum TypeImmobilier {
    HOUSE,
    LAND,
    VILLA,
    APPARTEMENT
}
