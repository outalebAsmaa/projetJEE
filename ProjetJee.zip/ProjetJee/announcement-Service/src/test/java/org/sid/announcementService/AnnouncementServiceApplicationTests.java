package org.sid.announcementService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnnouncementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
