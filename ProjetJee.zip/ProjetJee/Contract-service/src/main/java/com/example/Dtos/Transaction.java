package com.example.Dtos;

import lombok.Data;

@Data
public class Transaction {

    private String from_address;
    private String to_adsress;
    private long private_keys;
    
}
