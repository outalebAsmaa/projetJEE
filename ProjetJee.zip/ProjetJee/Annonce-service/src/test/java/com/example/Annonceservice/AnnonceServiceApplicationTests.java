package com.example.Annonceservice;

import com.example.lsi.entities.Immobilier;
import com.example.lsi.entities.Type;
import com.example.lsi.repository.ImmobilierRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnnonceServiceApplicationTests {




	//@Autowired
	//ImmobilierRepository immobilierRepository;
	@Test
	void contextLoads() {

	//	immobilierRepository.save(new Immobilier("tanger","url","boukhalef","azetyuio",1, Type.HOUSE));


	}

}
