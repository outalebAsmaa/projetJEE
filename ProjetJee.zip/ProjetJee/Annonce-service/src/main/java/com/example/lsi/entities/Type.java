package com.example.lsi.entities;

public enum Type {
    HOUSE,
    LAND,
    VILLA,
    APARTMENT
}
